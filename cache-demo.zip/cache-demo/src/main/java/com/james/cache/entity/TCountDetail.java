package com.james.cache.entity;

import java.io.Serializable;
import java.util.Date;


public class TCountDetail implements Serializable{
    private String id;

    private String ip;
   

	private Date optime;
    
    private String username;

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Date getOptime() {
		return optime;
	}

	public void setOptime(Date optime) {
		this.optime = optime;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}